"""Draw a balanced isoform panel: 100 from the observed tier, 50 from prediction-only.

Random sampling would hand back whatever the library is mostly made of. Multipass proteins
dominate the surfaceome by count, so an unstratified draw buries the classes a tag-placement
pipeline most needs to be exercised on — a GPI anchor behaves differently from a type I
receptor, and type II and type III differ from each other in exactly the way that decides
where a tag can go.

**Isoforms are binned by the class of the library gene they belong to, not by their own
topology.** An isoform of a type I receptor that happens to lose its signal peptide computes
as type III on its own sequence, and binning on that produced a panel with 20 type III
members when the library contains **13 type III genes in total**. The gene's class is the
property the panel is meant to span.

Classes, from the gene's selected reference:

* **GPI** — UniProt keyword KW-0336, taken first because a GPI protein's C-terminal signal
  is often called as a transmembrane helix and would otherwise be filed as type I;
* **multipass** — two or more TM helices;
* **type I** — one TM helix, signal peptide, extracellular N-terminus;
* **type II** — one TM helix, no signal peptide, cytoplasmic N-terminus;
* **type III** — one TM helix, no signal peptide, extracellular N-terminus (signal anchor).

Deterministic: the seed is fixed and recorded, so the panel is reproducible and a rerun
does not quietly hand back a different 150.

    uv run --locked python sample_isoform_panel.py
"""

from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from gpi import gpi_genes as gpi_gene_set

SEED = 20261009
N_OBSERVED = 100
N_PREDICTED = 50
# Floors for the classes too rare to survive a proportional draw. The library holds 33 type
# III, 126 type II and 135 GPI genes against 1,223 multipass and 836 type I, so without
# floors the two big classes take almost everything. Everything else is proportional.
FLOORS = {"type III": 2, "GPI": 5, "type II": 5}

ORIENT = {"O": "extracellular", "I": "cytoplasmic"}


def classify(tm: int, sp: int, n_term: str, is_gpi: bool) -> str:
    if is_gpi:
        return "GPI"
    if tm >= 2:
        return "multipass"
    if tm == 1:
        if sp > 0 and n_term == "extracellular":
            return "type I"
        if sp == 0 and n_term == "cytoplasmic":
            return "type II"
        if sp == 0 and n_term == "extracellular":
            return "type III"
        return "single-pass other"
    return "no TM helix"


def parse_3line(path: Path) -> dict[str, dict]:
    out: dict[str, dict] = {}
    if not path.exists():
        return out
    lines = path.read_text().splitlines()
    for i in range(len(lines) - 2):
        if not lines[i].startswith(">"):
            continue
        name, label = lines[i][1:].rsplit("|", 1)
        topo = lines[i + 2].strip()
        runs = sum(
            1 for j, c in enumerate(topo) if c == "M" and (j == 0 or topo[j - 1] != "M")
        )
        non_signal = [c for c in topo if c != "S"]
        first = next((c for c in non_signal if c in ORIENT), None)
        out[name.strip()] = {
            "tm": runs,
            "sp": topo.count("S"),
            "n_term": ORIENT.get(first, "indeterminate"),
        }
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--surfaceome-repo", default="~/Git/accessible-surfaceome")
    ap.add_argument("--cache-dir", default="~/.cache/deliverome/appris")
    ap.add_argument("--cohorts", default="isoform_cohorts.tsv")
    ap.add_argument("--selection", default="reference_selection.tsv")
    ap.add_argument(
        "--reference-three-line", default="library_reference_missing_topology.3line"
    )
    args = ap.parse_args()

    repo = Path(args.surfaceome_repo).expanduser()
    cache = Path(args.cache_dir).expanduser()

    gpi_genes = gpi_gene_set(args.cache_dir)

    # Topology per form: the cohort tables for UniProt-keyed forms, the new run for the rest.
    by_acc: dict[str, dict] = {}
    for name in ("deeptmhmm_human_canonical.tsv", "deeptmhmm_human_isoforms.tsv"):
        path = repo / "data/processed/deeptmhmm" / name
        if not path.exists():
            continue
        with path.open() as fh:
            for row in csv.DictReader(fh, delimiter="\t"):
                acc = row.get("uniprot_accession_full") or row.get("uniprot_accession")
                if acc:
                    by_acc[acc] = {
                        "tm": int(row["tm_helix_count"] or 0),
                        "sp": int(row["signal_peptide_length"] or 0),
                        "n_term": "extracellular"
                        if row.get("n_term_extracellular") == "1"
                        else "cytoplasmic",
                    }
    # References run separately because they were missing from the cohort.
    by_ref_gene: dict[str, dict] = {}
    ref3 = Path(args.reference_three_line)
    if ref3.exists():
        lines = ref3.read_text().splitlines()
        for i in range(len(lines) - 2):
            if not lines[i].startswith(">"):
                continue
            name, _label = lines[i][1:].rsplit("|", 1)
            parts = name.split("|")
            gene = parts[1] if len(parts) > 1 else name
            topo = lines[i + 2].strip()
            runs = sum(
                1 for j, c in enumerate(topo) if c == "M" and (j == 0 or topo[j - 1] != "M")
            )
            non_signal = [c for c in topo if c != "S"]
            first = next((c for c in non_signal if c in ORIENT), None)
            by_ref_gene[gene.strip()] = {
                "tm": runs,
                "sp": topo.count("S"),
                "n_term": ORIENT.get(first, "indeterminate"),
            }

    manifest = {
        (m["gene"], m["length"]): m["fasta_id"]
        for m in csv.DictReader(open("topology_shortlist.tsv"), delimiter="\t")
        if m["is_reference"] == "False"
    }
    by_fid = parse_3line(Path("topology_shortlist.3line"))

    # The class of each library GENE, from its selected reference.
    selection = {
        r["symbol"]: r for r in csv.DictReader(open(args.selection), delimiter="\t")
    }
    gene_class: dict[str, str] = {}
    for gene, srow in selection.items():
        acc = srow.get("selected_uniprot_equivalent") or srow.get("current_accession") or ""
        topo = by_acc.get(acc) or by_acc.get(acc.split("-")[0])
        if topo is None:
            topo = by_ref_gene.get(gene)
        if topo is not None:
            gene_class[gene] = classify(
                topo["tm"], topo["sp"], topo["n_term"], gene in gpi_genes
            )

    rows, unclassified = [], Counter()
    for r in csv.DictReader(open(args.cohorts), delimiter="\t"):
        cls = gene_class.get(r["gene"])
        if cls is None:
            unclassified[r["cohort_tier"]] += 1
            continue
        rows.append({**r, "topology_class": cls})

    # Genes whose own selected reference is secreted or intracellular cannot contribute to a
    # surface panel whatever their isoforms look like. Ten library genes are in this state
    # and they are written out rather than silently dropped: six are reported in the
    # literature as GPI-anchored but carry no GPI keyword and no lipidation feature in
    # UniProt, so classifying them here would be asserting something the annotation does not
    # say. Two others -- PILRA and LMLN -- reached it because the appris_only branch moved
    # their reference onto a soluble isoform.
    non_surface = sorted({
        r["gene"] for r in rows if r["topology_class"] in ("no TM (SP/GLOB)", "no TM helix")
    })
    if non_surface:
        Path("panel_excluded_non_surface_reference.txt").write_text(
            "\n".join(non_surface) + "\n"
        )
        print(
            f"excluded {len(non_surface)} gene(s) whose reference is not surface: "
            f"{', '.join(non_surface)}"
        )
    rows = [
        r for r in rows if r["topology_class"] not in ("no TM (SP/GLOB)", "no TM helix")
    ]

    print(f"classified {len(rows)} forms; no topology for {sum(unclassified.values())}")
    for tier, n in unclassified.most_common():
        print(f"  unclassified in {tier}: {n}")

    pools = {
        "observed": [r for r in rows if r["cohort_tier"] == "observed"],
        "prediction_only": [r for r in rows if r["cohort_tier"] == "full_only"],
    }
    print("\nclass distribution:")
    for tier, pool in pools.items():
        c = Counter(r["topology_class"] for r in pool)
        print(f"  {tier} ({len(pool)}): {dict(c.most_common())}")

    def allocate(pool: list[dict], n: int) -> dict[str, int]:
        """Floors for type III and GPI; the remainder split by largest remainder.

        Largest-remainder rather than rounding each share independently: rounding lets the
        big classes absorb the whole remainder and starve the small ones, which took type II
        from its proportional ~6 slots to 0 despite having 47 candidates.
        """
        by_cls = defaultdict(list)
        for r in pool:
            by_cls[r["topology_class"]].append(r)
        alloc = {c: min(FLOORS.get(c, 0), len(v)) for c, v in by_cls.items()}
        left = n - sum(alloc.values())
        spare = {c: len(v) - alloc[c] for c, v in by_cls.items()}
        total = sum(spare.values())
        if left > 0 and total > 0:
            exact = {c: left * spare[c] / total for c in spare}
            base = {c: min(int(v), spare[c]) for c, v in exact.items()}
            for c, k in base.items():
                alloc[c] += k
            short = left - sum(base.values())
            # hand out the leftover one at a time, largest fractional part first
            order = sorted(
                spare, key=lambda c: (exact[c] - int(exact[c]), spare[c]), reverse=True
            )
            i = 0
            while short > 0 and i < 50 * max(len(order), 1):
                c = order[i % len(order)]
                if alloc[c] - FLOORS.get(c, 0) < spare[c]:
                    alloc[c] += 1
                    short -= 1
                i += 1
        while sum(alloc.values()) > n:
            c = max(alloc, key=lambda c: alloc[c] - FLOORS.get(c, 0))
            alloc[c] -= 1
        return {c: k for c, k in alloc.items() if k}

    rng = random.Random(SEED)
    panel = []
    plan = {}
    for tier, want in (("observed", N_OBSERVED), ("prediction_only", N_PREDICTED)):
        pool = pools[tier]
        alloc = allocate(pool, want)
        plan[tier] = alloc
        by_cls = defaultdict(list)
        for r in pool:
            by_cls[r["topology_class"]].append(r)
        for cls, k in alloc.items():
            picked = rng.sample(by_cls[cls], k)
            for p in picked:
                panel.append({**p, "panel_tier": tier})

    panel.sort(key=lambda r: (r["panel_tier"], r["topology_class"], r["gene"]))
    with open("isoform_panel.tsv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(panel[0]), delimiter="\t")
        w.writeheader()
        w.writerows(panel)
    print(f"\nwrote isoform_panel.tsv ({len(panel)} forms)")

    summary = {
        "seed": SEED,
        "panel_size": len(panel),
        "floors": FLOORS,
        "allocation": plan,
        "by_class": dict(Counter(r["topology_class"] for r in panel).most_common()),
        "genes": len({r["gene"] for r in panel}),
        "already_in_cohort": sum(1 for r in panel if r["in_current_cohort"] == "True"),
    }
    Path("isoform_panel_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
